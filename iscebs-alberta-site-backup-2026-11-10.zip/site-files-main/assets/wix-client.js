/*
  Shared Wix connection helpers used by wix-board.js and wix-events.js.
  Settings (client ID, collection IDs) live in wix-config.js, not here.
*/
(() => {
  const settings = window.WIX_SETTINGS || {};
  const API = 'https://www.wixapis.com';
  let tokenPromise, tokenFromStore = false;

  const configured = () =>
    Boolean(settings.WIX_CLIENT_ID) && !String(settings.WIX_CLIENT_ID).startsWith('PASTE');

  async function request(path, options = {}) {
    const response = await fetch(API + path, { ...options, signal: AbortSignal.timeout(15000) });
    if (!response.ok) {
      const body = await response.json().catch(() => ({}));
      const err = new Error('Wix request failed: ' + response.status);
      err.status = response.status;
      err.code = body?.details?.applicationError?.code || '';
      throw err;
    }
    return response.json();
  }

  // Small localStorage helpers. Storage can be blocked (private mode, strict settings),
  // so every read/write is wrapped and the site works the same without it.
  const store = {
    get(key) { try { return JSON.parse(localStorage.getItem(key) || 'null'); } catch { return null; } },
    set(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); } catch {} },
    drop(key) { try { localStorage.removeItem(key); } catch {} }
  };
  const TOKEN_KEY = 'wix-visitor-token';

  // Anonymous visitor token: read-only access to public content. No admin keys.
  // Reused across pages and visits until shortly before it expires, which saves a
  // round trip to Wix on every page that shows CMS content.
  function getToken() {
    if (!tokenPromise) {
      const saved = store.get(TOKEN_KEY);
      if (saved?.token && saved.client === settings.WIX_CLIENT_ID && saved.expires > Date.now()) {
        tokenPromise = Promise.resolve(saved.token); tokenFromStore = true;
      } else {
        tokenPromise = request('/oauth2/token', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ clientId: settings.WIX_CLIENT_ID, grantType: 'anonymous' })
        }).then(t => {
          const life = Number(t.expires_in) || 3600; // seconds
          store.set(TOKEN_KEY, { token: t.access_token, client: settings.WIX_CLIENT_ID,
            expires: Date.now() + Math.max(0, life - 300) * 1000 });
          return t.access_token;
        }).catch(err => { tokenPromise = null; throw err; });
      }
    }
    return tokenPromise;
  }

  async function post(path, body, retried = false) {
    const token = await getToken();
    try {
      return await request(path, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: token },
        body: JSON.stringify(body)
      });
    } catch (err) {
      // A saved token Wix no longer accepts: get a fresh one and try once more.
      // (Only for a saved token, so a genuine refusal is never sent twice.)
      if (!retried && tokenFromStore && (err.status === 401 || err.status === 403)) {
        store.drop(TOKEN_KEY); tokenPromise = null; tokenFromStore = false;
        return post(path, body, true);
      }
      throw err;
    }
  }


  async function queryCollection(collectionId, sort = []) {
    const result = await post('/wix-data/v2/items/query',
      { dataCollectionId: collectionId, query: { sort, paging: { limit: 100 } } });
    return (result.dataItems || []).map(i => i.data || {});
  }

  // Field keys depend on how fields were named in Wix, so accept common variants.
  function field(item, ...keys) {
    for (const k of keys) {
      const v = item?.[k];
      if (v !== undefined && v !== null && String(v).trim() !== '') return v;
    }
    return '';
  }

  const esc = s => String(s ?? '').replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const safeLink = url => (/^https:\/\//i.test(String(url || '')) ? String(url) : '');

  // First picture inside a Wix Rich content value (used when a photo field is Rich content).
  function firstRichImage(doc) {
    const stack = [...(doc.nodes || [])];
    while (stack.length) {
      const n = stack.shift();
      const img = n.imageData?.image;
      const src = img?.src || n.galleryData?.items?.[0]?.image?.media?.src;
      if (src?.id && img?.width && img?.height && n.imageData?.crop) {
        // Respect a crop made in the Wix editor (crop values are fractions of the original).
        const c = n.imageData.crop, W = img.width, H = img.height;
        const px = v => Math.max(0, Math.round(v));
        return `https://static.wixstatic.com/media/${src.id}/v1/crop/x_${px(c.x * W)},y_${px(c.y * H)},w_${px(c.width * W)},h_${px(c.height * H)}/${src.id}`;
      }
      if (src) return src.url || src.id || '';
      if (n.nodes) stack.unshift(...n.nodes);
    }
    return '';
  }

  // Wix image value (wix:image://v1/<id>/<name>#...) -> public URL.
  function imageUrl(value) {
    if (!value) return '';
    if (typeof value === 'object' && Array.isArray(value.nodes)) value = firstRichImage(value); // Rich content field
    if (typeof value === 'object' && value) value = value.url || value.src || value.image || value.id || '';
    if (/^[\w-]+~mv2\.\w+$/.test(String(value))) return `https://static.wixstatic.com/media/${value}`;
    const m = String(value).match(/^(?:wix:)?image:\/\/v1\/([^/#?]+)/);
    if (m) return `https://static.wixstatic.com/media/${m[1]}`;
    return safeLink(value);
  }

  // Turn whatever an editor typed into a usable web link:
  // "linkedin.com/in/x", "www.x.com", "http://..." or a Rich content field with a link in it.
  function webLink(value) {
    if (!value) return '';
    if (typeof value === 'object' && Array.isArray(value.nodes)) {
      const stack = [...value.nodes];
      let text = '';
      while (stack.length) {
        const n = stack.shift();
        const url = n.textData?.decorations?.find(d => d.type === 'LINK')?.linkData?.link?.url || n.linkPreviewData?.link?.url;
        if (url) { value = url; break; }
        if (n.textData?.text) text += n.textData.text;
        if (n.nodes) stack.unshift(...n.nodes);
      }
      if (typeof value === 'object') value = text;
    }
    let v = String(value).trim();
    if (!v || /\s/.test(v)) return '';
    if (/^http:\/\//i.test(v)) v = 'https://' + v.slice(7);
    if (!/^https:\/\//i.test(v)) v = 'https://' + v.replace(/^\/+/, '');
    try { const u = new URL(v); return u.hostname.includes('.') ? u.href : ''; } catch { return ''; }
  }

  // Minimal Wix rich-text renderer: paragraphs, headings and lists, as plain text.
  function richText(rich) {
    const text = node => (node.nodes || []).map(n =>
      n.type === 'TEXT' ? esc(n.textData?.text || '') : text(n)).join('');
    const block = node => {
      switch (node.type) {
        case 'PARAGRAPH': { const t = text(node); return t.trim() ? `<p>${t.replace(/\n/g, '<br>')}</p>` : ''; }
        case 'HEADING': return `<h4>${text(node)}</h4>`;
        case 'BULLETED_LIST': return `<ul>${(node.nodes || []).map(li => `<li>${text(li)}</li>`).join('')}</ul>`;
        case 'ORDERED_LIST': return `<ol>${(node.nodes || []).map(li => `<li>${text(li)}</li>`).join('')}</ol>`;
        default: return '';
      }
    };
    return (rich?.nodes || []).map(block).join('');
  }

  window.WixSite = { settings, configured, store, post, queryCollection, field, esc, safeLink, webLink, imageUrl, richText };
})();
